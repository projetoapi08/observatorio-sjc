# Observatório do Ecossistema Industrial e de Serviços de São José dos Campos

Projeto da disciplina **API (Aprendizagem por Projetos Integrados)** — Fatec São José dos Campos, curso de Logística.

## Sobre o projeto

Dashboard em Power BI que mapeia o ecossistema industrial e de serviços do município de São José dos Campos/SP: empresas que mais contratam, setores em alta, impacto no PIB municipal e distribuição geográfica dos estabelecimentos. Inspirado no Observatório da Inovação RS (Rio Grande do Sul).

- **Cliente:** CADI e Secretaria de Desenvolvimento Econômico de São José dos Campos
- **Orientadores:** Prof. José Jaétis (M2) e Prof. Marcus (P2)
- **Autor:** Juliano Souza Santana

## Fontes de dados

- **RAIS** (Relação Anual de Informações Sociais — Ministério do Trabalho e Emprego)
- **PIB dos Municípios** (IBGE)

## Stack

- Google Colab + Python (ETL)
- Power BI (dashboard)
- GitHub (versionamento)

## Estrutura do repositório

```
observatorio-sjc/
├── docs/        # Documentação do projeto (Visão e Escopo, Backlog, DoR/DoD, Log de Decisões, Relatório Técnico)
├── notebooks/   # Notebooks do Google Colab (ETL dos dados RAIS)
└── powerbi/     # Arquivo(s) .pbix do dashboard
```

## Metodologia

Projeto conduzido em Scrum/API, organizado em 3 sprints, com backlog de produto, Definition of Ready (DoR), Definition of Done (DoD) e log de decisões de dados.
