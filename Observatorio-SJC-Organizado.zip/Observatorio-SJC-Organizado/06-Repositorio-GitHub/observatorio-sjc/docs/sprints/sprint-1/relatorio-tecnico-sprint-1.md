# Relatório Técnico — Sprint 1

**Período:** 24/ago a 28/set
**Meta da Sprint:** Ter os microdados da RAIS filtrados para o município de São José dos Campos, o dicionário de dados definido, os dados do PIB dos Municípios (IBGE) levantados, e uma primeira visualização simples (nº total de contratações em SJC) publicada no Power BI.

## O que foi entregue

O notebook de ETL no Google Colab rodou com sucesso, gerando o extrato RAIS filtrado (`RAIS_SJC_in_.csv`), 100% restrito ao código de município de São José dos Campos (354990). Foi produzida a suíte completa de documentos da Sprint 1 — Visão e Escopo, Backlog do Produto (11 User Stories), Backlog da Sprint 1, Checklist de DoR, DoD, Log de Decisões de Dados (DEC-001 a DEC-006) e este Relatório Técnico — além do checklist de erros/pendências enviado ao cliente. O repositório GitHub `observatorio-sjc/` foi estruturado com as pastas `docs/`, `notebooks/` e `powerbi/`.

## Metodologia e tecnologias utilizadas

- Fonte de dados: RAIS (ano 2024, confirmado pelo cliente — ver DEC-005), PIB dos Municípios IBGE (ano 2023 — série mais recente publicada; defasagem de 1 ano em relação à RAIS, documentada na DEC-005)
- Ferramentas: Google Colab + Python (bibliotecas: pandas), Power BI
- Etapas do tratamento de dados: filtragem do extrato pelo código de município 354990 (SJC); exclusão dos estabelecimentos com "RAIS negativa" — zero vínculos ativos — das análises de contratação (DEC-001, confirmada pelo cliente na DEC-006); segmentação por natureza de estabelecimento, restringindo o ranking principal a registros do tipo Cnpj (DEC-002, assumida pela equipe até confirmação formal do cliente)

## Dificuldades encontradas

Durante o tratamento dos dados, identificamos quatro problemas na base RAIS: (1) 68% dos estabelecimentos (32.281 de 47.339) sem nenhum vínculo ativo, exigindo decisão sobre inclusão ou exclusão nas análises; (2) mistura de três naturezas de estabelecimento (Cnpj, Caepf, Cno) numa mesma coluna; (3) ausência de um campo explícito de ano/competência no arquivo; (4) ausência de identificação nominal (razão social/CNPJ) das empresas. Além disso, ao confirmar o ano-base da RAIS (2024), identificamos que o PIB dos Municípios (IBGE) mais recente publicado é da série 2022–2023, criando uma defasagem de 1 ano em relação à RAIS que precisou ser tratada como limitação metodológica documentada (DEC-005).

## Decisões técnicas relevantes

Todas as decisões de tratamento de dados foram formalizadas no Log de Decisões de Dados, seguindo o modelo ADR: DEC-001 (exclusão da RAIS negativa das análises de contratação), DEC-002 (segmentação por natureza de estabelecimento, restrita a Cnpj), DEC-003 (ausência do campo de ano — resolvida pela DEC-005), DEC-004 (ausência de identificação nominal das empresas — uso de lista curada como camada complementar, não derivada da RAIS), DEC-005 (confirmação do ano-base RAIS 2024 e adoção do PIB 2023 como cruzamento válido, dada a defasagem do IBGE) e DEC-006 (confirmação do cliente sobre a exclusão da RAIS negativa, com formalização prevista em página de Notas Metodológicas no Power BI).

## Próximos passos (Sprint 2)

Aguardar retorno do cliente sobre a pergunta 2 em aberto (fornecimento de base RAIS identificada). Baixar e tratar a série do PIB dos Municípios 2022–2023 (IBGE), filtrada para São José dos Campos. Implementar a geocodificação por CEP dos estabelecimentos no Colab, viabilizando o mapeamento geográfico (User Story Rank 2). Iniciar a modelagem no Power BI com os dados tratados e montar a página de Notas Metodológicas (formalizando DEC-001/DEC-006). Planejar o backlog da Sprint 2.

## Links

- Vídeo de incremento: _____
- Notebook Colab: _____
- Arquivo Power BI: _____
