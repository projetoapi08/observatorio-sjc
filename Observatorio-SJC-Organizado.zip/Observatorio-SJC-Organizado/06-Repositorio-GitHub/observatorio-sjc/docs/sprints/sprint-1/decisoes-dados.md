# Log de Decisões de Dados — Sprint 1

> Técnica inspirada em ADR (Architecture Decision Record), adaptada para decisões sobre tratamento de dados. Cada vez que a equipe encontra um problema ou ambiguidade nos dados e toma uma decisão sobre como tratá-lo, registra-se aqui. Complementa (não substitui) o dicionário de dados.

---

### DEC-001 — Estabelecimentos com "RAIS negativa" (zero vínculos ativos)

- **Situação/Problema:** 68% dos estabelecimentos do extrato (32.281 de 47.339) têm `Qtd Vínculos Ativos = 0`, caracterizando declaração de "RAIS negativa" — o estabelecimento existe formalmente, mas não tinha nenhum vínculo empregatício ativo no ano de referência.
- **Decisão tomada:** Excluir estabelecimentos com `Qtd Vínculos Ativos = 0` das análises de ranking de empregadores e de setores em alta (User Stories Rank 3, 4 e 6). Manter a contagem total apenas se algum indicador futuro precisar de "total de estabelecimentos cadastrados" (distinto de "estabelecimentos ativos").
- **Justificativa:** Incluir esses registros nas análises de contratação distorceria os indicadores, tratando "existência formal" como "atividade empregadora" — são conceitos diferentes.
- **Impacto:** A base de análise de contratações passa de 47.339 para **15.058 estabelecimentos ativos**, somando **206.717 vínculos ativos**.
- **Responsável/Data:** Juliano Souza Santana — 16/09/2026

---

### DEC-002 — Mistura de tipos de estabelecimento (Cnpj, Caepf, Cno)

- **Situação/Problema:** A coluna `Tipo Estab_1` mistura três naturezas diferentes de registro: **Cnpj** (46.244 linhas), **Caepf** (708 — profissional autônomo/pessoa física) e **Cno** (387 — registro de obra de construção).
- **Decisão tomada:** Restringir a análise de "ranking de empresas/setores" a registros do tipo `Cnpj`. Caepf e Cno podem ser reportados separadamente, como nota complementar, se a equipe julgar relevante.
- **Justificativa:** O requisito do cliente pede mapeamento de "empresas" — CAEPF (pessoa física autônoma) e CNO (obra temporária) não representam empresas no sentido solicitado.
- **Impacto:** Exclusão de 1.095 registros (708 + 387) da análise principal — impacto pequeno no total, mas evita erro conceitual na apresentação.
- **Responsável/Data:** Juliano Souza Santana — 16/09/2026

---

### DEC-003 — Ausência do campo "Ano" no extrato

- **Situação/Problema:** O arquivo fornecido não contém uma coluna explícita indicando o ano-base da declaração RAIS.
- **Decisão tomada:** Confirmar com o colega responsável pela extração (e/ou com o cliente) qual ano da RAIS foi utilizado, atualizando esta entrada assim que confirmado. Até lá, tratar o dado como "ano não confirmado" em qualquer gráfico ou relatório publicado.
- **Justificativa:** O ano de referência é essencial para cruzar com o PIB dos Municípios (IBGE) no mesmo período (Sprint 3, User Story Rank 6) e para qualquer comparação temporal futura.
- **Impacto:** Bloqueia a User Story de Rank 6 (impacto no PIB) até confirmação; não impede o restante da Sprint 1.
- **Responsável/Data:** Juliano Souza Santana — 16/09/2026

---

### DEC-004 — Ausência de CNPJ/razão social (identificação de empresas)

- **Situação/Problema:** O extrato não contém identificação nominal das empresas (CNPJ, razão social) — apenas atributos agregados por estabelecimento (CNAE, porte, natureza jurídica, CEP).
- **Decisão tomada:** Não tentar inferir/"adivinhar" nomes de empresa a partir de CNAE + porte. Para a User Story de mapeamento geográfico e ranking nomeado (Rank 2 e 3), usar a lista curada de empresas conhecidas publicamente (fonte: slide "Ecossistema de Inovação de SJC" do cliente), tratada como uma camada complementar e documentada — não como derivada da RAIS.
- **Justificativa:** Dados identificados da RAIS são sigilosos por lei (acesso restrito a órgãos públicos autorizados); usar a RAIS pública para supor identidade de empresas seria metodologicamente incorreto e não verificável/auditável.
- **Impacto:** A camada de "nome de empresa" no produto final depende de fonte externa curada, não da RAIS. Aguardando também retorno do cliente sobre eventual acesso a dado identificado (mensagem já enviada).
- **Responsável/Data:** Juliano Souza Santana — 16/09/2026

---

### DEC-005 — Confirmação do ano-base da RAIS (2024) e defasagem com o PIB dos Municípios (IBGE)

- **Situação/Problema:** O cliente confirmou que o extrato RAIS utilizado tem ano-base **2024** (com parte do processamento/retificações se estendendo para 2025, o que é normal no fluxo da RAIS e não altera o ano de referência declarado). Essa confirmação resolve a DEC-003, mas expõe um novo problema: o PIB dos Municípios (IBGE) mais recente disponível é da série **2022–2023** (divulgada em dez/2025) — não existe PIB 2024 publicado, e a previsão de divulgação é apenas para o fim de 2026/2027.
- **Decisão tomada:** Adotar RAIS ano-base 2024 em todas as análises e visualizações. Para a User Story de impacto no PIB (Rank 6), cruzar com o **PIB municipal 2023** — o ano mais recente disponível — documentando explicitamente, no dashboard e no relatório técnico, a defasagem de 1 ano entre as duas fontes.
- **Justificativa:** O prazo do projeto (1 semestre letivo, 4 sprints) não comporta aguardar a divulgação do PIB 2024 pelo IBGE. Cruzar com o dado mais recente disponível, com a defasagem declarada como limitação metodológica, é prática padrão em estudos municipais que combinam RAIS e Contas Nacionais.
- **Impacto:** Desbloqueia a DEC-003 e a User Story de Rank 6 (impacto no PIB), antes impedida pela ausência de confirmação do ano. Fecha a pergunta 1 do checklist de erros ("qual o ano/competência de referência do arquivo RAIS?"). Qualquer gráfico que cruze RAIS x PIB deve indicar os anos de cada fonte (RAIS 2024 / PIB 2023) para evitar leitura equivocada.
- **Responsável/Data:** Juliano Souza Santana — 16/09/2026

### DEC-006 — Confirmação do cliente sobre o tratamento da RAIS negativa (referente à DEC-001)

- **Situação/Problema:** A exclusão dos estabelecimentos com `Qtd Vínculos Ativos = 0` das análises de contratação (DEC-001) era, até aqui, uma decisão interna da equipe — pendente de validação do cliente (pergunta 4 do checklist de erros).
- **Decisão tomada:** O cliente confirmou que a exclusão é aceitável. A DEC-001 fica mantida como definitiva. Para formalizar essa decisão de forma visível — tanto para o cliente quanto para a banca —, será criada uma página de **"Notas Metodológicas"** no Power BI, com indicadores mostrando o total de estabelecimentos do extrato, quantos foram excluídos por RAIS negativa e o percentual, com referência explícita à DEC-001.
- **Justificativa:** Documentar visualmente as decisões de tratamento de dados aumenta a transparência e a credibilidade do painel, e evita que a queda de 47.339 para 15.058 estabelecimentos seja lida como erro de extração em vez de decisão metodológica deliberada.
- **Impacto:** Fecha a pergunta 4 do checklist de erros. Adiciona um requisito para a Sprint 2/3: página de metodologia no Power BI.
- **Responsável/Data:** Juliano Souza Santana — 16/09/2026

## Como usar este log

- Toda nova decisão sobre tratamento de dado ganha uma entrada `DEC-00X` nova, nunca se edita o histórico de uma decisão já tomada (se a decisão mudar, registra-se uma nova entrada referenciando a anterior).
- Este arquivo deve ser citado no relatório técnico de cada sprint (`relatorio-tecnico-sprint-N.md`) sempre que uma decisão aqui registrada afetar o resultado apresentado.
