# Checklist de Erros e Inconsistências nos Dados (RAIS)

> Complemento ao Log de Decisões de Dados — Sprint 1

## 1. Contexto

Durante a etapa de análise de dados pelo (Google Colab) sobre a base RAIS filtrada para o município de São José dos Campos (código 354990), foram identificados problemas estruturais nos dados. Este documento consolida os erros já encontrados, seu impacto e o encaminhamento dado a cada um, servindo como checklist de verificação para as próximas sprints.

## 2. Checklist de erros identificados

| ID | Erro / Problema identificado | Impacto na análise | Ação / Decisão tomada | Status |
|---|---|---|---|---|
| DEC-001 | RAIS negativa em massa: aproximadamente 68% dos estabelecimentos com zero vínculos ativos. | Distorce indicadores de emprego se tratada junto com estabelecimentos ativos; infla a base sem representar geração de emprego real. | Segmentar estabelecimentos com vínculo > 0 dos com RAIS negativa antes de qualquer agregação de emprego. | Resolvido |
| DEC-002 | Mistura de naturezas de estabelecimento: CNPJ, CAEPF e CNO no mesmo arquivo. | Agregações somam entidades com naturezas jurídicas e finalidades distintas, gerando números não comparáveis. | Filtrar/segmentar por tipo de estabelecimento antes de qualquer análise agregada. | Resolvido |
| DEC-003 | Ausência do campo de ano/competência no arquivo de dados. | Sem essa informação não é possível datar a base nem garantir séries temporais corretas no dashboard. | Pergunta enviada ao cliente (Secretaria/CADI) solicitando confirmação do ano de referência do arquivo. | Resolvido — ver DEC-005 |
| DEC-004 | Ausência de identificação nominal: sem razão social ou CNPJ/CPF nos dados públicos da RAIS. | Impede análises que dependam de identificar estabelecimentos específicos (ex.: ranking de empregadores nomeados). | Pergunta enviada ao cliente sobre possibilidade de fornecer base identificada. | Pendente |

## 3. Checklist rápido (verificação para novas entregas de dados)

Use esta lista sempre que uma nova base de dados for recebida do cliente, antes de iniciar qualquer análise:

- [ ] O arquivo contém um campo de ano/competência claramente identificado?
- [ ] Existe mistura de naturezas jurídicas (CNPJ, CAEPF, CNO) que precise ser segmentada?
- [ ] Qual o percentual de registros com RAIS negativa (zero vínculos)? Foi segmentado?
- [ ] Os dados vêm identificados (razão social/CNPJ) ou anonimizados?
- [ ] O campo de CEP está presente e consistente, para viabilizar geocodificação?
- [ ] Os códigos de município correspondem exatamente a SJC (354990) em 100% dos registros?
- [ ] Há duplicidade de registros (mesmo estabelecimento aparecendo mais de uma vez)?
- [ ] Os tipos de dado (numérico, texto, data) estão consistentes coluna a coluna?

## 4. Perguntas em aberto ao cliente

- [RESPONDIDO pelo cliente — ano-base 2024, ver DEC-005] Qual é o ano/competência de referência do arquivo RAIS enviado? (relacionado a DEC-003)
- A Secretaria de Desenvolvimento Econômico pode fornecer uma base RAIS identificada (com razão social/CNPJ), mediante acordo de uso de dados? (relacionado a DEC-004)
- [ASSUMIDO PELA EQUIPE — seguindo o critério da DEC-002 até confirmação formal] Confirmar se a segmentação por natureza de estabelecimento (CNPJ/CAEPF/CNO) proposta em DEC-002 atende à expectativa do Observatório.
- [RESPONDIDO pelo cliente — excluir das análises de emprego, ver DEC-006] Validar se o tratamento da RAIS negativa (DEC-001) deve aparecer no dashboard como indicador próprio ou apenas ser excluído das análises de emprego.
- [NOVO — decorrente da DEC-005] O PIB dos Municípios (IBGE) mais recente publicado é a série 2022–2023; não há PIB 2024 disponível. Confirmar com o cliente se cruzar RAIS 2024 com PIB 2023 (defasagem de 1 ano, a ser documentada no dashboard) é aceitável para o Observatório.

## 5. Próximos passos

- Aguardar retorno do cliente sobre as perguntas da seção 4.
- Atualizar o Log de Decisões de Dados (`decisoes-dados.md`) assim que os problemas pendentes forem resolvidos.
