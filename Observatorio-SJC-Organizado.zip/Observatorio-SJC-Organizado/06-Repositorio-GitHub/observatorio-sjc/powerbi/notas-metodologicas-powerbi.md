# Notas Metodológicas — Página do Power BI

> Formaliza visualmente o tratamento da "RAIS negativa" (DEC-001) e sua confirmação pelo cliente (DEC-006). Referência: `decisoes-dados.md`.

## 1. Preparação do modelo (antes de montar a página)

### 1.1 Coluna calculada (Power Query ou DAX)

```
Status_Vinculo =
IF(RAIS[Qtd Vínculos Ativos] = 0, "RAIS Negativa", "Ativo")
```

Mantém os 47.339 registros no modelo — nada é apagado na origem, só classificado. Isso é o que permite a página de metodologia existir: sem essa coluna, não haveria como mostrar "o que foi excluído e por quê".

### 1.2 Medidas DAX

```
Total_Estabelecimentos =
COUNTROWS(RAIS)

Estabelecimentos_Ativos =
CALCULATE(COUNTROWS(RAIS), RAIS[Status_Vinculo] = "Ativo")

RAIS_Negativa =
CALCULATE(COUNTROWS(RAIS), RAIS[Status_Vinculo] = "RAIS Negativa")

Pct_RAIS_Negativa =
DIVIDE([RAIS_Negativa], [Total_Estabelecimentos])

Vinculos_Ativos_Total =
CALCULATE(SUM(RAIS[Qtd Vínculos Ativos]), RAIS[Status_Vinculo] = "Ativo")
```

### 1.3 Filtro nas páginas de análise

Nas páginas de ranking/setores em alta (não nesta página), aplique um **filtro de página**: `Status_Vinculo = "Ativo"`. A página de metodologia é a única que mostra os dois grupos lado a lado.

---

## 2. Layout da página

```
┌─────────────────────────────────────────────────────────────┐
│  NOTAS METODOLÓGICAS — TRATAMENTO DA BASE RAIS               │
├───────────────┬───────────────┬───────────────┬─────────────┤
│  CARTÃO 1      │  CARTÃO 2      │  CARTÃO 3      │  CARTÃO 4   │
│  Total no      │  Ativos        │  RAIS Negativa │  % Excluído │
│  extrato       │  (considerados)│  (excluídos)   │             │
│  47.339        │  15.058        │  32.281        │  68%        │
├───────────────┴───────────────┴────────────────┴─────────────┤
│                                                                 │
│   [Gráfico de rosca: Ativo vs RAIS Negativa]                   │
│                                                                 │
├─────────────────────────────────────────────────────────────┤
│  CAIXA DE TEXTO (ver seção 3)                                  │
│  Referência: DEC-001 · DEC-006 — Log de Decisões de Dados      │
└─────────────────────────────────────────────────────────────┘
```

- **Cartões (Card visual):** ligue cada um à medida correspondente (`Total_Estabelecimentos`, `Estabelecimentos_Ativos`, `RAIS_Negativa`, `Pct_RAIS_Negativa`).
- **Gráfico de rosca (Donut chart):** Legenda = `Status_Vinculo`, Valores = `Total_Estabelecimentos` (contagem). Cores sugeridas: verde/azul para "Ativo", cinza para "RAIS Negativa" (evita ler o excluído como "erro" ou "problema" em vermelho).
- **Caixa de texto:** abaixo do gráfico, texto fixo (não dinâmico).

---

## 3. Texto da caixa de texto (copiar direto)

> **Tratamento de estabelecimentos sem vínculos ativos ("RAIS negativa")**
>
> 68% dos estabelecimentos do extrato original (32.281 de 47.339) não tinham nenhum vínculo empregatício ativo no ano de referência — a chamada "RAIS negativa". Esses registros representam existência formal do estabelecimento, mas não atividade empregadora, e por isso foram excluídos das análises de ranking de empregadores e setores em alta.
>
> Essa exclusão foi validada com a Secretaria de Desenvolvimento Econômico de São José dos Campos. Os registros permanecem disponíveis na base para consulta e auditoria — apenas não entram nos indicadores de contratação.
>
> *Decisões relacionadas: DEC-001 (tratamento) e DEC-006 (confirmação do cliente) — Log de Decisões de Dados.*

---

## 4. Título e subtítulo da página

- **Título:** Notas Metodológicas
- **Subtítulo (opcional, abaixo do título):** Como os dados da RAIS foram tratados antes das análises

---

## 5. Checklist de montagem

- [ ] Coluna `Status_Vinculo` criada na tabela RAIS
- [ ] 5 medidas DAX criadas (seção 1.2)
- [ ] Página "Notas Metodológicas" criada, separada das páginas de análise
- [ ] 4 cartões inseridos e ligados às medidas
- [ ] Gráfico de rosca inserido (Ativo vs RAIS Negativa)
- [ ] Caixa de texto com o conteúdo da seção 3
- [ ] Filtro `Status_Vinculo = "Ativo"` aplicado nas páginas de ranking/setores
- [ ] Link/referência a DEC-001 e DEC-006 conferido no Log de Decisões
