# Observatório do Ecossistema Industrial e de Serviços de São José dos Campos

Projeto da metodologia **API — Aprendizagem por Projetos Integrados** (Fatec São José dos Campos), curso de Logística, 1º semestre de 2026.

## 📌 Sobre o projeto

Painel de Business Intelligence (Power BI), inspirado no modelo do **Observatório da Inovação RS**, que mapeia o ecossistema industrial e de serviços de São José dos Campos a partir de dados de contratações formais (**RAIS**) e do PIB municipal (**IBGE**). Permite identificar os maiores empregadores, os setores em crescimento, a distribuição geográfica das empresas e a participação estimada de cada setor no PIB municipal.

## 🎯 Desafio

**Cliente:** CADI e Secretaria de Desenvolvimento Econômico de São José dos Campos
**Tema oficial:** Mapeamento do Ecossistema Industrial e de Serviços da Região de São José dos Campos

Detalhes completos em [`docs/01-visao-e-escopo.md`](docs/01-visao-e-escopo.md).

## 👥 Equipe

| Nome | Papel | GitHub |
|---|---|---|
| _(preencher)_ | Product Owner | @_(usuário)_ |
| _(preencher)_ | Scrum Master | @_(usuário)_ |
| _(preencher)_ | Developer | @_(usuário)_ |
| _(preencher)_ | Developer | @_(usuário)_ |
| _(preencher)_ | Developer | @_(usuário)_ |

> Professor M2: José Jaétis · Professor P2: Marcus

## 🛠️ Tecnologias utilizadas

- **Google Colab + Python 3+** — coleta e tratamento dos microdados
- **Power BI** — modelagem e visualização
- **GitHub** — versionamento e documentação

## 📂 Documentação

- [Visão e Escopo](docs/01-visao-e-escopo.md)
- [Backlog do Produto](docs/backlog-produto.md)
- Sprints:
  - [Sprint 1](docs/sprints/sprint-1) — Fundação dos dados
  - [Sprint 2](docs/sprints/sprint-2) — Funcionalidades centrais
  - [Sprint 3](docs/sprints/sprint-3) — Integração e análise
  - [Sprint 4](docs/sprints/sprint-4) — Finalização

## 🔗 Links

- Painel Power BI: _(adicionar link após publicação)_
- Vídeo de incremento (Sprint atual): _(adicionar link do YouTube)_

## 📊 Fontes de dados

- [RAIS — Ministério do Trabalho e Emprego](https://www.gov.br/trabalho-e-emprego/pt-br/assuntos/estatisticas-trabalho)
- [PIB dos Municípios — IBGE](https://www.ibge.gov.br/estatisticas/economicas/contas-nacionais/9088-produto-interno-bruto-dos-municipios.html)

## 📅 Cronograma

| Data | Evento |
|---|---|
| 24/ago | Kick-off do projeto |
| 31/ago | Validação do entendimento |
| 28/set | Entrega 1 |
| 26/out | Entrega 2 |
| 23/nov | Entrega 3 |
| 03/dez | Feira de Soluções |
